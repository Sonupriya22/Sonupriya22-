# models.py
from django.db import models

class Subject(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Question(models.Model):
    text = models.CharField(max_length=200)

    def __str__(self):
        return self.text

class Feedback(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    response = models.CharField(max_length=10)  # e.g., Excellent, Good, Fair, Poor

    def __str__(self):
        return f"{self.subject.name} - {self.question.text} - {self.response}"
    
    
class User(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    
    def __str__(self):
        return self.username
    
    
class Student(models.Model):
    name = models.CharField(max_length=100)
    usn = models.CharField(max_length=100)
    branch = models.CharField(max_length=100)
    sem = models.IntegerField()

    def __str__(self):
        return self.name