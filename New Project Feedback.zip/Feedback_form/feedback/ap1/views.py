from django.shortcuts import render

# Create your views here.
# views.py
from django.shortcuts import render, redirect
from .models import Subject, Question, Feedback

def feedback_form(request):
    subjects = Subject.objects.all()
    questions = Question.objects.all()

    if request.method == "POST":
        subject_id = request.POST.get("subject")
        subject = Subject.objects.get(id=subject_id)

        for question in questions:
            response = request.POST.get(f"question_{question.id}")  # Get the selected checkbox value
            if response:  # Save only if a response is provided
                Feedback.objects.create(subject=subject, question=question, response=response)

        return redirect('feedback_success')

    return render(request, 'feedback_form.html', {'subjects': subjects, 'questions': questions})

def feedback_success(request):
    return render(request, 'feedback_success.html')

# views.py
from django.shortcuts import render, redirect
from .models import Subject, Question

def add_subject(request):
    if request.method == "POST":
        name = request.POST.get("name")
        Subject.objects.create(name=name)
        return redirect('add_subject_success')

    return render(request, 'add_subject.html')

def add_subject_success(request):
    return render(request, 'add_subject_success.html')

def add_question(request):
    if request.method == "POST":
        text = request.POST.get("text")
        Question.objects.create(text=text)
        return redirect('add_question_success')

    return render(request, 'add_question.html')

def add_question_success(request):
    return render(request, 'add_question_success.html')

def dashboard(request):
    return render(request, 'dashboard.html')


from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
from django.contrib.auth.hashers import make_password, check_password

def register(request):
    if request.method == "POST":
        # Use .get() to avoid the error if the key is missing
        username = request.POST.get('username')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password_confirm')

        # Check if the form fields exist
        if not username or not password or not password_confirm:
            messages.error(request, "All fields are required!")
            return redirect('register')

        if password != password_confirm:
            messages.error(request, "Passwords do not match!")
            return redirect('register')
        
        # Check if username already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect('register')
        
        # Hash password before saving
        hashed_password = make_password(password)
        new_user = User(username=username, password=hashed_password)
        new_user.save()

        messages.success(request, "Account created successfully!")
        return redirect('login')

    return render(request, 'register.html')

# Login View
def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        try:
            user = User.objects.get(username=username)
            if check_password(password, user.password):
                messages.success(request, "Login successful!")
                return redirect('dashboard')  # Redirect to dashboard or home page
            else:
                messages.error(request, "Invalid credentials!")
        except User.DoesNotExist:
            messages.error(request, "User does not exist!")
        
    return render(request, 'login.html')

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Student

# Register Student View
def register_student(request):
    if request.method == "POST":
        name = request.POST['name']
        usn = request.POST['usn']
        branch = request.POST['branch']
        sem = request.POST['sem']

        # Check if a student with the same USN already exists
        if Student.objects.filter(usn=usn).exists():
            messages.error(request, "Student with this USN already exists!")
            return redirect('register_student')

        # Create a new student record
        new_student = Student(name=name, usn=usn, branch=branch, sem=sem)
        new_student.save()

        messages.success(request, "Student registered successfully!")
        return redirect('register_student')  # Redirect to the registration page after successful registration

    return render(request, 'register_student.html')

# Display Students View
def display_students(request):
    students = Student.objects.all()
    return render(request, 'display_students.html', {'students': students})


def login_view(request):
    if request.method == "POST":
        # Get the name and usn from the form, using .get() to avoid errors
        name = request.POST.get('name')  # Use .get() to avoid errors if the field is missing
        usn = request.POST.get('usn')

        # Try to find the student with the provided name and usn
        try:
            student = Student.objects.get(name=name, usn=usn)
            # If student exists, log them in (you can implement your own session management or use Django's sessions)
            request.session['student_id'] = student.id
            return redirect('student_dashboard')  # Redirect to dashboard page after successful login
        except Student.DoesNotExist:
            messages.error(request, "Invalid name or USN")
            return redirect('student_login')  # Stay on the login page if student is not found

    return render(request, 'student_login.html')

def select_login(request):
    return render(request, 'select_login.html')


def student_dashboard(request):
    return render(request, 'student_dashboard.html')


from django.shortcuts import render
from .models import Question

def question_list(request):
    # Fetch all questions from the database
    questions = Question.objects.all()
    
    # Pass the questions to the template
    return render(request, 'question_list.html', {'questions': questions})
